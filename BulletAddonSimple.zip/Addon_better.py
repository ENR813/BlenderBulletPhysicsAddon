
bl_info = {
    "name": "My Threaded BulletPhysics python Binds",
    "category": "Object",
}
def register():
    print("Hello World")
def unregister():
    print("Goodbye World")